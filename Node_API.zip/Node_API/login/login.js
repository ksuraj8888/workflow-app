module.exports = function(app,fs){
    app.get('/login/:username/:password', (req,res) => {
        fs.readFile(__dirname + "/sample.json", 'utf8', (err,data) => {
			setTimeout(() =>{
				(req.params.username == "suraj" && req.params.password == "suraj") ? res.send({success:true,errorMessage:null}) : res.send({success:false,errorMessage:"Login error"}); 	
			},3000);
             
        })
    });
}