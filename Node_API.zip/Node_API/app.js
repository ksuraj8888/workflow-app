const express = require('express');
const cors = require('cors');
const app = express();
const fs = require('fs');
const port = 9500;
const result = require('./login/login');

app.use(cors())

result(app,fs);

app.listen(port,() => {
    
    console.log("App listening at");
})