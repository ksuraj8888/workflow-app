import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login/login.service';
import { Login } from './login.model';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginData: Login;
  username: string;
  password: string;
  isFocus: boolean = false;
  isSignIn: boolean = false;
  constructor(private loginService: LoginService, private router: Router, private toastr: ToastrService) { }

  ngOnInit() {

  }

  onSubmit() {
    this.isSignIn = true;
    this.toastr.success("Wait Logging you in");
    this.loginService.getLoginDetails(this.username, this.password).subscribe((details: Login) => {
      this.loginData = details;
      if (this.loginData.success) {
        this.toastr.success("User has successful login");
        this.router.navigate(['/dashboard']);
      }
      else {
        this.toastr.error("Not Logged in");
      }
    },
      error => {
        this.toastr.error("Login Error",error.description);
        this.isFocus = false;
        this.isSignIn = false;
      },
      () => {
        this.isFocus = false;
        this.isSignIn = false;
      }
    )
  }

}
