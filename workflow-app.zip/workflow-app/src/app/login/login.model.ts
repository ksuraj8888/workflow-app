export class Login{
    success:boolean;
    error:string;
}