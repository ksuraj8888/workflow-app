import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import * as AppConstant from '../app.constant';
@Injectable({
    providedIn:'root'
})

export class LoginService{
    constructor(private http:HttpClient) { }
    public getLoginDetails(username:string,password:string){
        return this.http.get(AppConstant.URL + "login/" + username + "/" + password);
    }
}