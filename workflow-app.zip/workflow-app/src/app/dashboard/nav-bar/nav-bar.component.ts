import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {

  constructor(private router:Router,private toastr:ToastrService) { }
  onLogOut(){
    this.toastr.success("Successfully Log Out");
    this.router.navigate(['login']);
  }
  ngOnInit() {
  }

}
