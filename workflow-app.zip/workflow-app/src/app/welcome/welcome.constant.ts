export const mainTitle = "ABC Corporation";
export const subTitle = "A team for building Modern Product";
export const featureContent = {
    "Modern Tech Stack":"Angular 6 and Bootstrap Environment.",
    "Advanced UI Kit Support":"Stylish Mockups that meet with Design.",
    "Advanced Components":"Advanced Features and Functionality to Application.",
    "Extensible Themes Support":"Light/Dark and other stylish themes."
};