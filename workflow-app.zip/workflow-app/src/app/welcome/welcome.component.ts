import { Component, OnInit } from '@angular/core';
import * as WelcomeConstant from './welcome.constant';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit {
  mainTitle:string;
  subTitle:string;
  featureKeys:string[];
  features:any;
  constructor() { }

  ngOnInit() {
    this.mainTitle = WelcomeConstant.mainTitle;
    this.subTitle = WelcomeConstant.subTitle;
    this.features = WelcomeConstant.featureContent;
    this.featureKeys = Object.keys(this.features);
  }

}
